package net.ukr.airsys.efforts.controller;

public interface Controller {

	void control();

}