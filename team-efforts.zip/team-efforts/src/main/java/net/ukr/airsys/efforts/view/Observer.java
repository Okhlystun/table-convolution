package net.ukr.airsys.efforts.view;

public interface Observer {
   
   void update();
}
