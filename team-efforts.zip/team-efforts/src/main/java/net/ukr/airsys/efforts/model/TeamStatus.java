package net.ukr.airsys.efforts.model;

public record TeamStatus (String team, String status) { }